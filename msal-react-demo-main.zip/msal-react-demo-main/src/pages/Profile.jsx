import { ProfileData } from "../components/ProfileData";
import { useMsalAuthentication } from "@azure/msal-react";
import { useState, useEffect } from "react";
import { InteractionType } from "@azure/msal-browser";
import { fetchData } from "../components/fetch";
import { useMsal } from "@azure/msal-react";
import jwtDecode from 'jwt-decode';

export const Profile = () => {

    const [graphData, setGraphData] = useState(null);
    const [showPopup, setShowPopup] = useState(false);
    const [load, setLoad] = useState(true)
    const { instance } = useMsal();
    const { accounts } = useMsal();
    const account = accounts[0];
    const { result, error } = useMsalAuthentication(InteractionType.Redirect, {
        scopes: ["user.read"]
    })
    useEffect(() => {
        const loginRequest = {
            scopes: ["user.read"],
        };

        instance
            .loginPopup(loginRequest)
            .then(async (response) => {
                console.log("**** Access Token in Profile **** ", response.accessToken);
                const decodedToken = jwtDecode(response.accessToken);
                if (decodedToken) {
                    // 'exp' represents the expiration time as a Unix timestamp
                    const expirationTime = decodedToken.exp;

                    console.log('Token Expiration Time:', expirationTime);
                    // You can convert the Unix timestamp to a JavaScript Date object for easier manipulation
                    const expirationDate = new Date(expirationTime * 1000);

                    // Now you can work with the expiration time
                    console.log('Token Expiration Time:', expirationDate);

                    // Get the current time in seconds
                    const currentTimeInSeconds = Math.floor(Date.now() / 1000);

                    // Calculate the difference
                    const timeDifferenceInSeconds = expirationTime - currentTimeInSeconds;

                    console.log('Time Difference (seconds):', timeDifferenceInSeconds);

                    if(timeDifferenceInSeconds < 60000){
                        setShowPopup(true);
                    }

                } else {
                    console.log('Invalid token format');
                }

                const graphEndpoint = "https://graph.microsoft.com/v1.0/me";
                const headers = new Headers();
                headers.append("Authorization", `Bearer ${response.accessToken}`);

                try {
                    const graphResponse = await fetch(graphEndpoint, { headers });
                    if (!graphResponse.ok) {
                        throw new Error("Failed to fetch profile data");
                    }
                    const userData = await graphResponse.json();
                    // Update the state with the profile data
                    console.log('***** User Data *****', userData)
                    setGraphData(userData);
                } catch (error) {
                    console.error("Error fetching profile data:", error);
                }
            })
            .catch((error) => {
                console.error("Error during login:", error);
                setLoad(false); // Set loading to false in case of login error
            });


    }, [instance]);

    const handleExtendSession = () => {
        instance.ssoSilent({ scopes: ["user.read"] }).catch((error) => {
            console.error("Failed to extend session:", error);
        });
        setShowPopup(false);
    };

    const handleSignOut = () => {
        instance.logoutRedirect();
    };

    if (showPopup) {
        return (
            <div>
                <p>Your session is about to expire.</p>
                <button onClick={handleExtendSession}>Extend Session</button>
                <button onClick={handleSignOut}>Sign Out</button>
            </div>
        );
    }
    return (
        <>
            {graphData ? (
                <div>
                    <p>Display Name: {graphData.displayName}</p>
                    <p>Job Title: {graphData.jobTitle}</p>
                    <p>Email: {graphData.mail}</p>
                    {/* Render other properties as needed */}
                </div>
            ) : (
                <p>Loading...</p>
            )}
        </>
    )
}