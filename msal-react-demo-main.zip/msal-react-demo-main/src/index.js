import React from 'react';
import ReactDOM from 'react-dom/client';

import { ThemeProvider } from '@mui/material/styles';
import { theme } from "./styles/theme";

import { BrowserRouter } from "react-router-dom";

import App from './App';

import { PublicClientApplication, EventType } from '@azure/msal-browser';

const baseURL= window.location.origin

console.log('**** base URL ***', baseURL)

const pca = new PublicClientApplication({
    auth:{
        clientId:'aee0e51c-8bee-45e3-a676-b124a98d40b1',
        authority:'https://login.microsoftonline.com/c3065180-2b8a-4617-b8d0-ba2308b71111/',
        redirectUri:'http://localhost:3000/profile',
    },
    cache:{
        cacheLocation: 'sessionStorage',
        storeAuthStateInCookie: false,
    },
    system:{
        loggerOptions:{
            loggerCallback:(level, message, containsPii) => {
                console.log(message)
            },
            logLevel: "Info",
        }
    }
})

pca.addEventCallback(event =>{
    if (event.eventType === EventType.LOGIN_SUCCESS){
        console.log(event);
        pca.setActiveAccount(event.payload.account)
    }
})

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
    <React.StrictMode>
        <BrowserRouter>
            <ThemeProvider theme={theme}>
                <App msalInstance={pca}/>
            </ThemeProvider>
        </BrowserRouter>
    </React.StrictMode>
);
