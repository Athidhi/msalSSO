import Button from '@mui/material/Button';
import { useMsal } from '@azure/msal-react';
import { useNavigate } from 'react-router-dom';

export const SignOutButton = () => {
    const {instance} = useMsal();
    const navigate = useNavigate();
    const {accounts} = useMsal()
    const account = accounts[0]; // Assuming there's a logged-in user
    const idToken = account.idToken;

    console.log('**** ID Token ***', idToken)

    const loginHint = idToken?.claims?.login_hint;

    const handleSignOut = () => {
        const logoutRequest = {
            account, 
            loginHint,
        }
        instance.logoutRedirect(logoutRequest)
        navigate('/')
    }
    return (
        <Button color="inherit" onClick={handleSignOut}>Sign out</Button>
    )
};