import { useMsal } from "@azure/msal-react";
import { useEffect } from "react";

const AutoLogout = () => {
  const { instance, accounts } = useMsal();

  useEffect(() => {
    const checkTokenExpiration = async () => {
      const activeAccount = accounts[0]; // Assuming you have a single account
      if (activeAccount) {
        const tokenResponse = await instance.acquireTokenSilent({
          scopes: ["user.read"],
          account: activeAccount,
        });
        if (tokenResponse.expiresOn < new Date()) {
          instance.logout();
        }
      }
    };

    const interval = setInterval(checkTokenExpiration, 60000); // Check every minute

    return () => clearInterval(interval);
  }, [instance, accounts]);

  return null;
};

export default AutoLogout;
